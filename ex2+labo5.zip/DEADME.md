# UE19-LAB-05: Application Python pour interroger une API publique

## Fonctionnalités
Cette application interroge l'API publique JokesAPI pour afficher une blague.

## Installation
1. Clonez le dépôt GitHub :
   ```bash
   git clone <URL_DU_DEPOT>
   cd ue19-lab-05
